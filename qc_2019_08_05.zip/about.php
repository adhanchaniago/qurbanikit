<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->
	<head>
		<meta charset="utf-8" />
		<title>Student Register</title>
		
		<meta name="Author" content="Syed Khaleel Ullah Hussiani" />

		<!-- mobile settings -->
		<meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />
		<!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->

		<!-- WEB FONTS : use %7C instead of | (pipe) -->
		<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400%7CRaleway:300,400,500,600,700%7CLato:300,400,400italic,600,700" rel="stylesheet" type="text/css" />

		<!-- CORE CSS -->
		<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
		
		<!-- THEME CSS -->
		<link href="assets/css/essentials.css" rel="stylesheet" type="text/css" />
		<link href="assets/css/layout.css" rel="stylesheet" type="text/css" />

		<!-- PAGE LEVEL SCRIPTS -->
		<link href="assets/css/header-1.css" rel="stylesheet" type="text/css" />
		<link href="assets/css/color_scheme/green.css" rel="stylesheet" type="text/css" id="color_scheme" />
	</head>

	
	<body class="smoothscroll enable-animation">

		


		<!-- wrapper -->
		<div id="wrapper">


			
			


			
			<section class="page-header page-header-xs">
				<div class="container">
					<img src="assets/images/logo.png" class="img-responsive center-block" style="width:120px; height:auto; align:center;" alt="JILT">
					

					<!-- breadcrumbs -->
					<!-- breadcrumbs -->
					<ol class="breadcrumb">
						<li><a href="index.php">Home</a></li>
						<li><a href="about.php">About</a></li>
						<li><a href="#" class=" dropdown-toggle" data-toggle="dropdown">Participants</a>
							<ul class="dropdown-menu">
							  <li><a href="gulbarga.php">Gulbarga</a></li>
							  <li><a href="mbnr.php">Mahabubnagar</a></li>
							</ul>
						</li>
						<li><a href="trainer.php">Trainers</a></li>
						<li><a href="gallery.php">Gallery</a></li>
					</ol>
					<!-- /breadcrumbs -->



				</div>
			</section>
			<!-- /PAGE HEADER -->

			<section>
				<div class="container">
					
					
					<?php
  	 include 'db.php';
	 $query = "select *from about order by rand() LIMIT 0,1";
	 $run = mysql_query($query);
	 while($row = mysql_fetch_array($run)){
		 $id = $row['id'];
		 $title = $row['title'];
		 $image = $row['image'];
		 $content = substr($row['content'],0,2000);
	 
  ?>
					<!-- BORN TO BE A WINNER -->
					<article class="row">
						<div class="col-md-6">
							<div>
								<img class="img-responsive" src="cms/images/about/<?php echo $image; ?>" alt="">
							</div>
						</div>
						<div class="col-md-6">
							<h3><?php echo $title; ?></h3>
							<p><?php echo $content; ?></p>
							
						</div>
					</article>
					<!-- /BORN TO BE A WINNER -->
	 <?php } ?>
					<div class="divider divider-center divider-color"><!-- divider -->
						<i class="fa fa-chevron-down"></i>
					</div>
					
					<?php
  	 include 'db.php';
	 $query = "select *from imp order by rand() LIMIT 0,1";
	 $run = mysql_query($query);
	 while($row = mysql_fetch_array($run)){
		 $id = $row['id'];
		 $title = $row['title'];
		 $image = $row['image'];
		 $content = substr($row['content'],0,2000);
	 
  ?>
					<!-- BORN TO BE A WINNER -->
					<article class="row">
						
						<div class="col-md-6">
							<h3><?php echo $title; ?></h3>
							<p><?php echo $content; ?></p>
							
						</div>
						<div class="col-md-6">
							<div>
								<img class="img-responsive" src="cms/images/imp/<?php echo $image; ?>" alt="">
							</div>
						</div>
					</article>
					<?php } ?>
					<!-- /BORN TO BE A WINNER -->
					<div class="divider divider-center divider-color"><!-- divider -->
						<i class="fa fa-chevron-down"></i>
					</div>
					<!-- BORN TO BE A WINNER -->
					
					<?php
  	 include 'db.php';
	 $query = "select *from after order by rand() LIMIT 0,1";
	 $run = mysql_query($query);
	 while($row = mysql_fetch_array($run)){
		 $id = $row['id'];
		 $title = $row['title'];
		 $image = $row['image'];
		 $content = substr($row['content'],0,2000);
	 
  ?>
					<article class="row">
						<div class="col-md-6">
							<div>
								<img class="img-responsive" src="cms/images/after/<?php echo $image; ?>" alt="">
							</div>
						</div>
						<div class="col-md-6">
							<h3><?php echo $title; ?></h3>
							<p><?php echo $content; ?></p>
							
						</div>
					</article>
					<!-- /BORN TO BE A WINNER -->
					<?php } ?>

				</div>
			</section>

			
		

		</div>
		<!-- /wrapper -->


		<!-- SCROLL TO TOP -->
		<a href="#" id="toTop"></a>


	<!-- FOOTER -->
			<footer id="footer" >

				<div class="copyright">
					<div class="container">
						
						&copy; All Rights Reserved, JILT Pvt Ltd
					</div>
				</div>

			</footer>
			<!-- /FOOTER -->


		<!-- JAVASCRIPT FILES -->
		<script type="text/javascript">var plugin_path = 'assets/plugins/';</script>
		<script type="text/javascript" src="assets/plugins/jquery/jquery-2.2.3.min.js"></script>

		<script type="text/javascript" src="assets/js/scripts.js"></script>
		
		
	</body>
</html>