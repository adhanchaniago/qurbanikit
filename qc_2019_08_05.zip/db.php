<?php
	
	/*	online  */
$host = "localhost";
$user = "jilt_qurbanikit";
$password = "[9D+rTsR^4FZ";
$database = "jilt_qurbanikit";

		/*Local*/
/*$host = "localhost";
$user = "root";
$password = "";
$database = "qurbanikit";*/

$con=@mysql_connect($host,$user,$password) or die("Failed to connect to MySQL: " . mysql_error());
$db=mysql_select_db($database,$con) or die("Failed to connect to MySQL: " . mysql_error());
?>
