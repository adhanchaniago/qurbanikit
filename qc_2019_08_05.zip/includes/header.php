<section class="page-header page-header-xs">
				<div class="container">
					<a href="index.php"><img src="assets/images/logo.png" class="img-responsive center-block" style="width:120px; height:auto; align:center;" alt="JILT"></a>
					

					<!-- breadcrumbs -->
					<ol class="breadcrumb">
						<li><a href="index.php">Home</a></li>
						<!--<li><a href="about.php">About</a></li>
						<li><a href="#" class=" dropdown-toggle" data-toggle="dropdown">Participants</a>
							<ul class="dropdown-menu">
							  <li><a href="gulbarga.php">Gulbarga</a></li>
							  <li></li>
							  <li><a href="mbnr.php">Mahabubnagar</a></li>
							</ul>
						</li>
						<li><a href="campaign.php">Campaign</a></li>
						<li><a href="trainer.php">Trainers</a></li>
						<li><a href="gallery.php">Gallery</a></li>-->
					</ol>
					<!-- /breadcrumbs -->


				</div>
			</section>